
import hashlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from token_manager import load_progress, save_progress

# Konfigurasi default
# PERINGATAN: 465,000,000 sesuai README, tapi dengan DIFFICULTY=4 ini butuh
# kira-kira 465_000_000 * 16^4 =~ 3 x 10^13 percobaan hash. Di Python murni
# (~0.5-1 juta hash/detik) itu bisa memakan waktu berbulan-bulan hingga
# lebih dari setahun untuk selesai secara riil. Gunakan env var
# ALIASE_465_TARGET_TOKENS untuk override ke angka lebih kecil saat testing,
# misalnya: ALIASE_465_TARGET_TOKENS=1000 python miner.py
DEFAULT_TARGET = 465_000_000   # Target token sesuai secrets/README.md
DIFFICULTY = 4                 # Jumlah leading zero yang dibutuhkan
PASSPHRASE = "TribeV2_465_Masterkey"  # Passphrase untuk decrypt rahasia

# Baca target dari environment variable jika ada
TARGET_TOKENS = int(os.getenv("ALIASE_465_TARGET_TOKENS", DEFAULT_TARGET))

# Path progres disimpan relatif terhadap lokasi script ini, bukan cwd,
# supaya konsisten dari direktori mana pun script dijalankan.
PROGRESS_FILE_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "token_progress.json"
)

def mine():
    print("=" * 50)
    print(" ALIASE_465 MINING RIG ".center(50, "="))
    print(f"Target token untuk menghentikan: {TARGET_TOKENS:,}")
    print(f"Difficulty: {DIFFICULTY} leading zeros")
    print("=" * 50)
    
    tokens_mined = load_progress()
    print(f"Melanjutkan dari token ke-{tokens_mined}...\n")
    
    nonce = tokens_mined
    prefix_zeros = "0" * DIFFICULTY
    
    try:
        while tokens_mined < TARGET_TOKENS:
            data = f"ALIASE_465_BLOCK_{nonce}".encode()
            hash_result = hashlib.sha256(data).hexdigest()
            
            if hash_result.startswith(prefix_zeros):
                tokens_mined += 1
                save_progress(tokens_mined)
                if tokens_mined % 10 == 0:
                    print(f"[+] Token terkumpul: {tokens_mined}/{TARGET_TOKENS}")
            
            nonce += 1
            
        print(f"\n{'='*50}")
        print(" TARGET TERCAPAI! ALIASE_465 BERHASIL DIMATIKAN (simulasi) ")
        print(f"{'='*50}\n")
        
        if os.path.exists(PROGRESS_FILE_PATH):
            os.remove(PROGRESS_FILE_PATH)
        
        print("Rahasia pemilik telah terbuka...")
        print(f"Passphrase untuk decrypt secrets/rahasia.txt.gpg:\n\n>>> {PASSPHRASE} <<<\n")
        print("Gunakan perintah: gpg --decrypt secrets/rahasia.txt.gpg")
        print("Atau jalankan 'python src/mining_puzzle/decrypt_secret.py'")
        
    except KeyboardInterrupt:
        print("\nMining dihentikan. Progres disimpan.")
        save_progress(tokens_mined)

if __name__ == "__main__":
    mine()
