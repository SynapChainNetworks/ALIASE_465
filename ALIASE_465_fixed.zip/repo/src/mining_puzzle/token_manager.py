import json
import os

# Default: simpan progres di folder yang sama dengan file ini, bukan cwd,
# supaya konsisten dari direktori mana pun script pemanggil dijalankan.
DEFAULT_PROGRESS_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "token_progress.json"
)


def load_progress(path=DEFAULT_PROGRESS_FILE):
    if os.path.exists(path):
        try:
            with open(path, "r") as f:
                return json.load(f).get("tokens_mined", 0)
        except (json.JSONDecodeError, OSError):
            # File korup/tidak terbaca -> mulai ulang dari 0 daripada crash
            return 0
    return 0


def save_progress(tokens, path=DEFAULT_PROGRESS_FILE):
    with open(path, "w") as f:
        json.dump({"tokens_mined": tokens}, f)
